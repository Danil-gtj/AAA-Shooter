// Fill out your copyright notice in the Description page of Project Settings.


#include "Character/UI/Widgets/World/GCAtrributeProgressBar.h"
#include "Components/ProgressBar.h"

void UGCAtrributeProgressBar::SetProgressPercantage(float Percentage)
{
	
}

void UGCAtrributeProgressBar::SetAttributeSet(UGCCharacterAttributeSet* AttributeSet_In)
{
	
}

float UGCAtrributeProgressBar::GetHealthPercent() const
{
	return 0.0f;
}
