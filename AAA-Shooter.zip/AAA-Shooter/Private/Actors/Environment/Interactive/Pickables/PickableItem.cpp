// Fill out your copyright notice in the Description page of Project Settings.


#include "Actors/Environment/Interactive/Pickables/PickableItem.h"

const FName& APickableItem::GetDataTableID() const
{
	return DataTableID;
}
