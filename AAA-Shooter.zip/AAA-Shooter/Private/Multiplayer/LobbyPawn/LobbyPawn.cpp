#include "Multiplayer/LobbyPawn/LobbyPawn.h"

ALobbyPawn::ALobbyPawn()
{

}

void ALobbyPawn::BeginPlay()
{
	Super::BeginPlay();
	
}

